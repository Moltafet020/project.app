package com.app.works;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class Works_Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static List<Works_Model> work_model =new ArrayList<>();
    private Context context;

    public void add(Works_Model model,Context context) {

        work_model.add(model);
        this.context=context;
        notifyItemInserted(work_model.lastIndexOf(model));
    }

    @SuppressLint("NotifyDataSetChanged")
    public void clear()
    {
        work_model.clear();
        notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.work_model, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return work_model.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        public LinearLayout layout_child;
        public LinearLayout work_options;
        public TextView subject;
        public TextView details;
        public Button edit_work;
        public Button delete_work;

        public MyViewHolder(final View itemView) {
            super(itemView);

            layout_child = itemView.findViewById(R.id.layout_child);
            work_options = itemView.findViewById(R.id.work_options);
            subject = itemView.findViewById(R.id.work_subject);
            details = itemView.findViewById(R.id.work_details);
            edit_work = itemView.findViewById(R.id.work_edit);
            delete_work = itemView.findViewById(R.id.work_delete);

        }

        public void bind(final Works_Model model, int po) {

            if(model.getWork_status()==0)
            {
                layout_child.setBackgroundResource(R.color.red_mine);
                work_options.setBackgroundResource(R.color.work_red_mine);
            }
            else
            {
                layout_child.setBackgroundResource(R.color.green_mine);
                work_options.setBackgroundResource(R.color.work_green_mine);
            }

            subject.setText(model.getWork_subject());
            details.setText(model.getWork_details());

            layout_child.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent show=new Intent(context,Show_Work.class);
                    show.putExtra("Work_id",model.getWork_id());
                    context.startActivity(show);
                }
            });

            edit_work.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent edit=new Intent(context,Add_Work.class);
                    edit.putExtra("Mode",1);
                    edit.putExtra("Work_id",model.getWork_id());
                    context.startActivity(edit);

                }
            });

            delete_work.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    show_alert(context.getString(R.string.alert_msg),po);
                }
            });

        }

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ((MyViewHolder) holder).bind(work_model.get(position),position);

    }

    void show_alert(String msg,int pos)
    {
        play_sound();
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage(msg);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                R.string.positive,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        delete_of_db(pos);
                        work_model.remove(pos);
                        notifyItemRemoved(pos);
                        dialog.cancel();

                    }
                });

        builder1.setNegativeButton(
                R.string.negative,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void play_sound()
    {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(context, notification);
        r.play();
    }

    private void delete_of_db(int id)
    {
        id=work_model.get(id).work_id;
        SQLiteDatabase database;
        database=context.openOrCreateDatabase("works_db",MODE_PRIVATE,null);
        database.execSQL("DELETE FROM works WHERE ID= '"+id+"'");
        database.close();

    }

}
