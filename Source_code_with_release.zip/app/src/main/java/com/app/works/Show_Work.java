package com.app.works;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class Show_Work extends AppCompatActivity {

    TextView status,subject,details,date;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_work);

        status=findViewById(R.id.status_show);
        subject=findViewById(R.id.subject_show);
        details=findViewById(R.id.details_show);
        date=findViewById(R.id.date_show);

        Intent intent=getIntent();
        int work_id=intent.getIntExtra("Work_id",0);

        database=openOrCreateDatabase("works_db",MODE_PRIVATE,null);

        Cursor reader=database.rawQuery("SELECT Work_Status,Work_Subject,Work_Details,Work_Date FROM works WHERE ID = '"+work_id+"'",null);
        if (reader.moveToFirst())
        {
            if(reader.getInt(0)==1)
            {
                status.setText(getString(R.string.done));
            }
            else
            {
                status.setText(getString(R.string.undone));
            }

            subject.setText(reader.getString(1));
            details.setText(reader.getString(2));
            date.setText(reader.getString(3));
        }
        reader.close();
        database.close();

    }
}