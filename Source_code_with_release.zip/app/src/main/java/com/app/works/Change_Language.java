package com.app.works;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Change_Language extends AppCompatActivity {

    RadioGroup selected_language;
    RadioButton english,persian,arabic;
    Button save;
    private SharedPreferences preferences;
    private String selected_lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_language);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        selected_language=findViewById(R.id.selected_lang);
        english=findViewById(R.id.english_lang);
        persian=findViewById(R.id.persian_lang);
        arabic=findViewById(R.id.arabic_lang);

        save=findViewById(R.id.save_lang);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selected_language.getCheckedRadioButtonId() == english.getId())
                {
                    selected_lang = "en";
                }
                else if(selected_language.getCheckedRadioButtonId() == persian.getId())
                {
                    selected_lang="fa";
                }
                else if(selected_language.getCheckedRadioButtonId() == arabic.getId())
                {
                    selected_lang="ar";
                }
                else
                {
                    selected_lang="";
                    Toast.makeText(Change_Language.this, "Please choose a Language", Toast.LENGTH_SHORT).show();
                }

                if(selected_lang.length()>0)
                {
                    preferences.edit().putString("Language", selected_lang).apply();
                    startActivity(new Intent(Change_Language.this,MainActivity.class));
                    finish();
                }

            }
        });
    }

}