package com.app.works;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Add_Work extends AppCompatActivity {

    SQLiteDatabase database;
    EditText subject,details,date;
    RadioGroup status;
    RadioButton done,undone;
    Button save;
    Calendar myCalendar= Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_work);

        subject=findViewById(R.id.subject_add);
        details=findViewById(R.id.details_add);
        date=findViewById(R.id.date_add);

        status=findViewById(R.id.status_add);
        done=findViewById(R.id.done_add);
        undone=findViewById(R.id.undone_add);

        save=findViewById(R.id.save_add);

        database=openOrCreateDatabase("works_db",MODE_PRIVATE,null);

        DatePickerDialog.OnDateSetListener date_picker =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yy", Locale.US);
                date.setText(dateFormat.format(myCalendar.getTime()));
            }
        };

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Add_Work.this,date_picker,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        Intent intent =getIntent();
        int mode=intent.getIntExtra("Mode",0);
        int work_id=intent.getIntExtra("Work_id",0);

        if(mode==1)
        {
            Cursor read_edit=database.rawQuery("SELECT Work_Status,Work_Subject,Work_Details,Work_Date FROM works WHERE ID = '"+work_id+"'",null);
            if(read_edit.moveToFirst())
            {
                int sts=read_edit.getInt(0);

                if(sts==1)
                {
                    done.setChecked(true);
                }
                else
                {
                    undone.setChecked(true);
                }

                subject.setText(read_edit.getString(1));
                details.setText(read_edit.getString(2));
                date.setText(read_edit.getString(3));
            }
            read_edit.close();

        }

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(subject.getText().toString().length()>0)
                {
                    if(details.getText().toString().length()>0)
                    {
                        if(date.getText().toString().length()>0)
                        {

                            if(status.getCheckedRadioButtonId()==done.getId()||status.getCheckedRadioButtonId()==undone.getId())
                            {
                                int sts=0;
                                if(status.getCheckedRadioButtonId()==done.getId())
                                {
                                    sts=1;
                                }

                                database=openOrCreateDatabase("works_db",MODE_PRIVATE,null);

                                database.execSQL("CREATE TABLE IF NOT EXISTS works (ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,Work_Status INTEGER, Work_Subject TEXT, Work_Details TEXT, Work_Date)");

                                ContentValues contentValues=new ContentValues();

                                contentValues.put("Work_Status",sts);
                                contentValues.put("Work_Subject",subject.getText().toString());
                                contentValues.put("Work_Details",details.getText().toString());
                                contentValues.put("Work_Date",date.getText().toString());
                                if(mode==1)
                                {
                                    String[] whereArgs = new String[] {String.valueOf(work_id)};
                                    database.update("works",contentValues,"ID=?",whereArgs);
                                }
                                else
                                {
                                    database.insert("works",null,contentValues);
                                }
                                database.close();
                                show_message(getString(R.string.success_added));
                                play_sound();
                                finish();

                            }
                            else
                            {
                                show_message(getString(R.string.status_choice));
                            }
                        }
                        else
                        {
                            show_message(getString(R.string.date_choice));
                        }
                    }
                    else
                    {
                        show_message(getString(R.string.details_choice));
                    }
                }
                else
                {
                    show_message(getString(R.string.subject_choice));
                }

            }
        });

    }

    private void show_message(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void play_sound()
    {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
    }

}