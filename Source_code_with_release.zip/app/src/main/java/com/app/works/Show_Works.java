package com.app.works;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Show_Works extends AppCompatActivity {

    FloatingActionButton floatingActionButton;
    Works_Adapter works_adapter;
    RecyclerView works_parent;
    SQLiteDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_works);

        floatingActionButton=findViewById(R.id.add_work);
        works_parent=findViewById(R.id.works_parent);

        works_adapter=new Works_Adapter();

        works_parent.setHasFixedSize(false);
        works_parent.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        works_parent.setAdapter(works_adapter);

        try
        {
            database=openOrCreateDatabase("works_db",MODE_PRIVATE,null);
            Cursor reader=database.rawQuery("SELECT * FROM works",null);
            while (reader.moveToNext())
            {

                works_adapter.add(new Works_Model(
                        reader.getInt(0),
                        reader.getInt(1),
                        reader.getString(2),
                        reader.getString(3)),Show_Works.this);

            }
            reader.close();
            database.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this, getString(R.string.add_work_pl), Toast.LENGTH_SHORT).show();
        }
    floatingActionButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            startActivity(new Intent(Show_Works.this,Add_Work.class));
        }
    });

    }

    @Override
    protected void onPause() {
        super.onPause();
        works_adapter.clear();
        finish();
    }
}