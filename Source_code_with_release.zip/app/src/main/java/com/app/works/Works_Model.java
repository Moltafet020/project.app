package com.app.works;

public class Works_Model {

    int work_status, work_id;
    String work_subject, work_details;

    public Works_Model(int work_id, int work_status, String work_subject, String work_details) {
        this.work_id =work_id;
        this.work_status = work_status;
        this.work_subject = work_subject;
        this.work_details = work_details;
    }

    public int getWork_id() {
        return work_id;
    }

    public int getWork_status() {
        return work_status;
    }

    public String getWork_subject() {
        return work_subject;
    }

    public String getWork_details() {
        return work_details;
    }
}
