package com.app.works;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

     SharedPreferences preferences;
     String selected_lang;

    @Override
    protected void attachBaseContext(Context newBase) {
        preferences = PreferenceManager.getDefaultSharedPreferences(newBase);

        if(Locale.getDefault().getLanguage().contains("en"))
        {
            selected_lang = preferences.getString("Language", "en");
        }
        else if(Locale.getDefault().getLanguage().contains("fa"))
        {
            selected_lang = preferences.getString("Language", "fa");
        }
        else
        {
            selected_lang = preferences.getString("Language", "ar");
        }

        Context context = changeLanguage(newBase, selected_lang);
        super.attachBaseContext(context);
    }

    Button show_works,add_work,change_language;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        show_works = findViewById(R.id.show_works_main);
        add_work = findViewById(R.id.add_work_main);
        change_language = findViewById(R.id.change_lang_main);

        show_works.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Show_Works.class));
            }
        });

        add_work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Add_Work.class));
            }
        });

        change_language.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Change_Language.class));
                finish();
            }
        });
    }

    public static ContextWrapper changeLanguage(Context context, String lang) {
        Locale        currentLocal;
        Resources res  = context.getResources();
        Configuration conf = res.getConfiguration();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            currentLocal = conf.getLocales().get(0);
        } else {
            currentLocal = conf.locale;
        }

        if (!currentLocal.getLanguage().equals(lang)) {
            Locale newLocal = new Locale(lang);
            Locale.setDefault(newLocal);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                conf.setLocale(newLocal);
            } else {
                conf.locale = newLocal;
            }

            context = context.createConfigurationContext(conf);

        }

        return new ContextWrapper(context);
    }

}
